import org.springframework.web.context.request.RequestContextHolder as RCH
import org.codehaus.groovy.grails.commons.GrailsClassUtils as GCU
import org.springframework.validation.Errors
import org.codehaus.groovy.grails.validation.ConstrainedPropertyBuilder

class CommandoGrailsPlugin {
    def version = 0.1
    def dependsOn = [core:0.4]
	def watchedResources = ["controllers"]
    // TODO Fill in these fields
    def author = "Zan Thrash"
    def authorEmail = "zan@zanthrash.com"
    def title = "Commando"
    def description = '''\
Provies a factory to create and properly wire up command objects so you don't have to
always passs as a parameter to your action.
'''

    // URL to the plugin's documentation
    def documentation = "http://grails.org/Commando+Plugin"

    def doWithSpring = {
        // TODO Implement runtime spring config (optional)
    }
   
    def doWithApplicationContext = { applicationContext ->
        // TODO Implement post initialization spring config (optional)		
    }

    def doWithWebDescriptor = { xml ->
        // TODO Implement additions to web.xml (optional)
    }
	                                         
    def doWithDynamicMethods = { ctx ->
       application.controllerClasses.each { cClass ->
            cClass.metaClass.createCommand = { commandObjectClass ->
                def commandObject = commandObjectClass.newInstance()
                def commandObjectMetaClass = commandObject.metaClass
                commandObjectMetaClass.setErrors = {Errors errors ->
                    RCH.currentRequestAttributes().setAttribute("${commandObjectClass.name}_errors", errors, 0)
                }
                commandObjectMetaClass.getErrors = {->
                    RCH.currentRequestAttributes().getAttribute("${commandObjectClass.name}_errors", 0)
                }

                commandObjectMetaClass.hasErrors = {->
                    errors?.hasErrors() ? true : false
                }
                def validationClosure = GCU.getStaticPropertyValue(commandObjectClass, 'constraints')
                if (validationClosure) {
                    def constrainedPropertyBuilder = new ConstrainedPropertyBuilder(commandObject)
                    validationClosure.setDelegate(constrainedPropertyBuilder)
                    validationClosure()
                    commandObjectMetaClass.constraints = constrainedPropertyBuilder.constrainedProperties
                } else {
                    commandObjectMetaClass.constraints = [:]
                }
                return commandObject 
            }
       }
    }
	
    def onChange = { event ->
        // TODO Implement code that is executed when any artefact that this plugin is
        // watching is modified and reloaded. The event contains: event.source,
        // event.application, event.manager, event.ctx, and event.plugin.
    }

    def onConfigChange = { event ->
        // TODO Implement code that is executed when the project configuration changes.
        // The event is the same as for 'onChange'.
    }
}
