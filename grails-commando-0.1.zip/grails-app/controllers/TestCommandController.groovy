class TestCommandController {

    def create = {
	    def command = createCommand(PersonCommmand)
		bindData(command, params)
	    return command.validate()
    }
}
