

public class PersonCommand {
	String firstName
	String lastName
	String middleInitial

	static constraints = {
		firstName(nullable:false, blank:false, range:2..8)
		lastName(nullable:false, blank:false, range:2..10)
		middleInitial(nullable:true, blank:false, max:1)
	}
}